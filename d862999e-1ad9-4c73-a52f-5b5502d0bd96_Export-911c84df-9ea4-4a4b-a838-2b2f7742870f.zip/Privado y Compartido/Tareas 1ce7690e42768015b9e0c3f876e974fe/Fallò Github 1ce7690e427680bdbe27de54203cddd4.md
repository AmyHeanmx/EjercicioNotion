# Fallò Github

Estado: Bloqueado
Prioridad: Media
Responsable: Carlos Adrián Hinojosa Morales
Fecha límite: 8 de abril de 2025