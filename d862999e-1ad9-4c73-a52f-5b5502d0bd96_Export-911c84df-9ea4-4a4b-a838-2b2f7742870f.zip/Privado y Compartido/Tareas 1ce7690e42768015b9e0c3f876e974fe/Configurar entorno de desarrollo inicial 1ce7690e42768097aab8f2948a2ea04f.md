# Configurar entorno de desarrollo inicial

Estado: En progreso
Prioridad: Alta
Fecha límite: 10 de abril de 2025