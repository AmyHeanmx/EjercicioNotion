# Diseñar arquitectura base del proyecto

Estado: Ideas
Prioridad: Alta
Fecha límite: 12 de abril de 2025