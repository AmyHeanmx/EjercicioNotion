# Documentacion

Estado: Hecho
Prioridad: Baja
Issue GitHub: Tenemos un inconveniente de inicio de sesiones en GitHub
Responsable: Carlos Adrián Hinojosa Morales
Fecha límite: 10 de abril de 2025